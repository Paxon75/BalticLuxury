import React, { useState } from 'react';
import type { Apartment } from '../types';
import { handleSmoothScroll } from '../utils/smoothScroll';

interface ApartmentCardProps {
  apartment: Apartment;
}

export const ApartmentCard = ({ apartment }: ApartmentCardProps) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % apartment.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex - 1 + apartment.images.length) % apartment.images.length);
  };


  return (
    <div className="bg-white rounded-lg shadow-2xl overflow-hidden flex flex-col lg:flex-row my-8">
      <div className="lg:w-1/2 relative">
        <img src={apartment.images[currentImageIndex]} alt={apartment.name} className="w-full h-80 object-cover" />
         <div className="absolute inset-0 bg-black bg-opacity-10 flex justify-between items-center px-4">
            <button onClick={prevImage} aria-label="Poprzednie zdjęcie" className="text-white bg-black bg-opacity-40 rounded-full p-2 hover:bg-opacity-60 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
            </button>
            <button onClick={nextImage} aria-label="Następne zdjęcie" className="text-white bg-black bg-opacity-40 rounded-full p-2 hover:bg-opacity-60 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
            </button>
        </div>
      </div>
      <div className="p-8 lg:w-1/2 flex flex-col justify-center">
        <h3 className="text-3xl font-bold text-slate-900">{apartment.name}</h3>
        <p className="text-amber-600 font-semibold mt-1 mb-6">{apartment.subtitle}</p>
        <p className="text-slate-600 mb-6 leading-relaxed">{apartment.description}</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 mb-6">
          {apartment.features.map(feature => (
            <div key={feature.label} className="flex items-center space-x-3">
              {feature.icon}
              <div>
                <p className="font-semibold text-slate-700">{feature.value}</p>
                <p className="text-sm text-slate-500">{feature.label}</p>
              </div>
            </div>
          ))}
        </div>
        <a href="#kontakt" onClick={handleSmoothScroll} className="self-start mt-4 bg-amber-500 text-white font-bold py-3 px-8 rounded-lg hover:bg-amber-600 transition-all duration-300 shadow-lg hover:shadow-xl">
          Zapytaj o termin
        </a>
      </div>
    </div>
  );
};