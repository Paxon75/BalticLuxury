
import React from 'react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-slate-900 text-slate-400">
      <div className="container mx-auto px-6 py-8 text-center">
        <p>&copy; {currentYear} BalticLuxury. Wszelkie prawa zastrzeżone.</p>
        <p className="text-sm mt-2">Projekt i wykonanie z dbałością o każdy detal.</p>
      </div>
    </footer>
  );
};

export default Footer;
