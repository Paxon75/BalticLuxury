
import React from 'react';

export const BedIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M2 4v16h20V4H2z" />
    <path d="M2 10h20" />
    <path d="M8 14v-4" />
    <path d="M16 14v-4" />
  </svg>
);
