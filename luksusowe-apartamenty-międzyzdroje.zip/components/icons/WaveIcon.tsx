
import React from 'react';

export const WaveIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M2 12c.9.9 2.1 1.4 3.4 1.4 1.3 0 2.5-.5 3.4-1.4.9-.9 2.1-1.4 3.4-1.4s2.5.5 3.4 1.4c.9.9 2.1 1.4 3.4 1.4 1.3 0 2.5-.5 3.4-1.4" />
    <path d="M2 6c.9.9 2.1 1.4 3.4 1.4 1.3 0 2.5-.5 3.4-1.4.9-.9 2.1-1.4 3.4-1.4s2.5.5 3.4 1.4c.9.9 2.1 1.4 3.4 1.4 1.3 0 2.5-.5 3.4-1.4" />
    <path d="M2 18c.9.9 2.1 1.4 3.4 1.4 1.3 0 2.5-.5 3.4-1.4.9-.9 2.1-1.4 3.4-1.4s2.5.5 3.4 1.4c.9.9 2.1 1.4 3.4 1.4 1.3 0 2.5-.5 3.4-1.4" />
  </svg>
);
