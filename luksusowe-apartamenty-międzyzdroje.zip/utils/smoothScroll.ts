import React from 'react';

/**
 * Handles smooth scrolling to an element on the page, accounting for a fixed header.
 * @param e The mouse event from the anchor tag click.
 */
export const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>) => {
  e.preventDefault();
  const href = e.currentTarget.getAttribute('href');
  if (!href || href === '#') {
    // Scroll to top if href is '#' or missing
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }

  const targetId = href.substring(1);
  const targetElement = document.getElementById(targetId);

  if (targetElement) {
    // Offset to account for the fixed header height. 80px should be sufficient.
    const headerOffset = 80;
    const elementPosition = targetElement.getBoundingClientRect().top;
    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth',
    });
  }
};
